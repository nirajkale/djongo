# This version of Djongo was made possible by
# the generous contributions from:
#
#       * TechDragon
#       * Zachary Sizemore
#       * Wayne Van Son
#       * Norman Niemer
#       * Renz Ladia
#       * thestick613

__version__ = '1.2.38'
